﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace RaceDayAPI.Models
{

    public class Event
    {
        [Key]
        public int EventID { get; set; } // Primary Key, auto-incremented in the database[cite: 4]

        [Required]
        public int OrganiserID { get; set; } // Foreign Key linking back to the Users table (Organiser)[cite: 4]

        [Required]
        [StringLength(150)]
        public string Title { get; set; } = string.Empty; // Title of the race event (e.g., Soweto Marathon)[cite: 4, 8]

        public string? Description { get; set; } // Optional detailed description of the event[cite: 4]

        [Required]
        [StringLength(150)]
        public string Location { get; set; } = string.Empty; // Location where the event takes place[cite: 4]

        [Required]
        public DateTime EventDate { get; set; } // Date and time of the event[cite: 4]

        public DateTime CreatedAt { get; set; } = DateTime.Now; // Timestamp when the event was created[cite: 4]

        // Navigation properties for Entity Framework relationships
        [ForeignKey("OrganiserID")]
        public User? Organiser { get; set; } // The user account that organised this event[cite: 4]

        public ICollection<Category> Categories { get; set; } = new List<Category>(); // Distance categories linked to this event[cite: 5]
        public Route? Route { get; set; } // Route specification linked to this event[cite: 7]
    }

}
