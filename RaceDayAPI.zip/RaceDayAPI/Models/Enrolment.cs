﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace RaceDayAPI.Models
{


    public class Enrolment
    {
        [Key]
        public int EnrolmentID { get; set; } // Primary Key, auto-incremented in the database[cite: 5]

        [Required]
        public int ParticipantID { get; set; } // Foreign Key linking to the User (Participant) registering[cite: 5]

        [Required]
        public int CategoryID { get; set; } // Foreign Key linking to the Category being entered[cite: 5, 6]

        public DateTime EnrolmentDate { get; set; } = DateTime.Now; // Date and time when the enrolment was created[cite: 5]

        [Required]
        [StringLength(20)]
        public string Status { get; set; } = "Confirmed"; // Restricted status: 'Confirmed' or 'Cancelled'[cite: 5, 6]

        // Navigation properties for Entity Framework relationships
        [ForeignKey("ParticipantID")]
        public User? Participant { get; set; } // The participant user account

        [ForeignKey("CategoryID")]
        public Category? Category { get; set; } // The category being entered

        public Result? Result { get; set; } // 1-to-1 relationship with the race result record[cite: 6]
    }

}
