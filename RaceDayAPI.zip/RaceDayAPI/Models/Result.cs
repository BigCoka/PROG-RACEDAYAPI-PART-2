﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace RaceDayAPI.Models
{

    public class Result
    {
        [Key]
        public int ResultID { get; set; } // Primary Key, auto-incremented in the database[cite: 6]

        [Required]
        public int EnrolmentID { get; set; } // Foreign Key linking to Enrolments (Unique for 1-to-1 relationship)[cite: 6, 7]

        public TimeSpan? FinishTime { get; set; } // Time taken to finish the race (hours, minutes, seconds)[cite: 6]

        [Range(1, int.MaxValue)]
        public int? OverallPosition { get; set; } // Final placement position (must be greater than 0)[cite: 6]

        [Required]
        [StringLength(20)]
        public string Status { get; set; } = "Finished"; // Status: 'Finished', 'DNF' (Did Not Finish), or 'DNS' (Did Not Start)[cite: 6, 7]

        // Navigation properties for Entity Framework relationships
        [ForeignKey("EnrolmentID")]
        public Enrolment? Enrolment { get; set; } // The parent enrolment record this result belongs to[cite: 7]
    }

}
