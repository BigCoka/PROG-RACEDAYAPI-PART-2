﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

    namespace RaceDayAPI.Models
    {
        public class Route
        {
            [Key]
            public int RouteID { get; set; } // Primary Key, auto-incremented in the database[cite: 7]

            [Required]
            public int EventID { get; set; } // Foreign Key linking to Events (Unique for 1-to-1 relationship)[cite: 7]

            [StringLength(500)]
            public string? GpxDataUrl { get; set; } // URL pointing to the GPX route file (optional)[cite: 7]

            [Range(0, int.MaxValue)]
            public int? ElevationGainMeters { get; set; } // Total elevation gain in meters (must be 0 or positive)[cite: 7]

            public string? Description { get; set; } // Text description of the route specification[cite: 7]

            // Navigation properties for Entity Framework relationships
            [ForeignKey("EventID")]
            public Event? Event { get; set; } // The parent event this route belongs to[cite: 7]
        }
    }