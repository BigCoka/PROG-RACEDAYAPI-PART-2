﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDayAPI.Data;
using RaceDayAPI.Models;

namespace RaceDayAPI.Controllers
{
    [Route("api/users")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public UsersController(RaceDayDbContext context)
        {
            _context = context;
        }

        // GET: api/users/profile/{id}
        [HttpGet("profile/{id}")]
        public async Task<IActionResult> GetUserProfile(int id)
        {
            var user = await _context.Users
                .Include(u => u.Enrolments)
                .ThenInclude(e => e.Category)
                .ThenInclude(c => c!.Event)
                .Include(u => u.Events)
                .FirstOrDefaultAsync(u => u.UserID == id);

            if (user == null)
            {
                return NotFound(new { message = "User profile not found." });
            }

            // Return user profile details securely (excluding PasswordHash)
            return Ok(new
            {
                userId = user.UserID,
                fullName = user.FullName,
                email = user.Email,
                role = user.Role,
                createdAt = user.CreatedAt,
                events = user.Events,
                enrolments = user.Enrolments
            });
        }
    }
}