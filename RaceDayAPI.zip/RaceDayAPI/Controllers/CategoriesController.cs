﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDayAPI.Data;
using RaceDayAPI.Models;

namespace RaceDayAPI.Controllers
{
    [Route("api/events/{eventId}/categories")]
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public CategoriesController(RaceDayDbContext context)
        {
            _context = context;
        }

        // GET: api/events/{eventId}/categories
        [HttpGet]
        public async Task<IActionResult> GetCategoriesForEvent(int eventId)
        {
            // Verify event exists
            var eventExists = await _context.Events.AnyAsync(e => e.EventID == eventId);
            if (!eventExists)
            {
                return NotFound(new { message = "Event does not exist." });
            }

            var categories = await _context.Categories
                .Where(c => c.EventID == eventId)
                .ToListAsync();

            return Ok(categories);
        }

        // POST: api/events/{eventId}/categories
        [HttpPost]
        public async Task<IActionResult> CreateCategory(int eventId, [FromBody] Category categoryDto)
        {
            // Verify event exists
            var eventExists = await _context.Events.AnyAsync(e => e.EventID == eventId);
            if (!eventExists)
            {
                return NotFound(new { message = "Event does not exist." });
            }

            if (eventId != categoryDto.EventID)
            {
                categoryDto.EventID = eventId;
            }

            // Validate constraints (DistanceKM > 0, EntryFee >= 0)
            if (categoryDto.DistanceKM <= 0 || categoryDto.EntryFee < 0)
            {
                return BadRequest(new { message = "Invalid distance (must be > 0) or entry fee (must be >= 0)." });
            }

            _context.Categories.Add(categoryDto);
            await _context.SaveChangesAsync();

            return StatusCode(201, categoryDto);
        }
    }
}