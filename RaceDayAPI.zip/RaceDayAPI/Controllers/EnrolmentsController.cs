﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDayAPI.Data;
using RaceDayAPI.Models;

namespace RaceDayAPI.Controllers
{
    [Route("api/enrolments")]
    [ApiController]
    public class EnrolmentsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public EnrolmentsController(RaceDayDbContext context)
        {
            _context = context;
        }

        // DTO for Enrolment Request
        public class EnrolmentDto
        {
            public int ParticipantID { get; set; }
            public int CategoryID { get; set; }
        }

        // DTO for Result Recording Request
        public class ResultDto
        {
            public TimeSpan? FinishTime { get; set; }
            public int? OverallPosition { get; set; }
            public string Status { get; set; } = "Finished"; // 'Finished', 'DNF', 'DNS'
        }

        // POST: api/enrolments
        [HttpPost]
        public async Task<IActionResult> CreateEnrolment([FromBody] EnrolmentDto dto)
        {
            // Verify participant exists and has 'Participant' role
            var participant = await _context.Users.FindAsync(dto.ParticipantID);
            if (participant == null || participant.Role != "Participant")
            {
                return BadRequest(new { message = "Invalid Participant ID or user is not a Participant." });
            }

            // Verify category exists
            var category = await _context.Categories.FindAsync(dto.CategoryID);
            if (category == null)
            {
                return NotFound(new { message = "Category does not exist." });
            }

            // Check for duplicate enrolment (UQ_Participant_Category constraint)
            var existingEnrolment = await _context.Enrolments
                .FirstOrDefaultAsync(e => e.ParticipantID == dto.ParticipantID && e.CategoryID == dto.CategoryID);

            if (existingEnrolment != null)
            {
                return Conflict(new { message = "Participant is already enrolled in this category." });
            }

            var enrolment = new Enrolment
            {
                ParticipantID = dto.ParticipantID,
                CategoryID = dto.CategoryID,
                EnrolmentDate = DateTime.Now,
                Status = "Confirmed"
            };

            _context.Enrolments.Add(enrolment);
            await _context.SaveChangesAsync();

            return StatusCode(201, enrolment);
        }

        // GET: api/enrolments/my-enrolments/{participantId}
        [HttpGet("my-enrolments/{participantId}")]
        public async Task<IActionResult> GetMyEnrolments(int participantId)
        {
            var enrolments = await _context.Enrolments
                .Include(e => e.Category)
                .ThenInclude(c => c!.Event)
                .Where(e => e.ParticipantID == participantId)
                .ToListAsync();

            return Ok(enrolments);
        }

        // GET: api/events/{eventId}/enrolments (Note: handled via route attribute below)
        [HttpGet("/api/events/{eventId}/enrolments")]
        public async Task<IActionResult> GetEventEnrolments(int eventId)
        {
            var enrolments = await _context.Enrolments
                .Include(e => e.Participant)
                .Include(e => e.Category)
                .Where(e => e.Category!.EventID == eventId)
                .ToListAsync();

            return Ok(enrolments);
        }

        // POST: api/enrolments/{enrolmentId}/results
        [HttpPost("{enrolmentId}/results")]
        public async Task<IActionResult> RecordResult(int enrolmentId, [FromBody] ResultDto dto)
        {
            var enrolment = await _context.Enrolments.FindAsync(enrolmentId);
            if (enrolment == null)
            {
                return NotFound(new { message = "Enrolment record not found." });
            }

            // Check if result already exists for this enrolment
            var existingResult = await _context.Results.FirstOrDefaultAsync(r => r.EnrolmentID == enrolmentId);
            if (existingResult != null)
            {
                return BadRequest(new { message = "A result record already exists for this enrolment." });
            }

            var result = new Result
            {
                EnrolmentID = enrolmentId,
                FinishTime = dto.FinishTime,
                OverallPosition = dto.OverallPosition,
                Status = dto.Status
            };

            _context.Results.Add(result);
            await _context.SaveChangesAsync();

            return StatusCode(201, result);
        }

        // GET: api/enrolments/my-results/{participantId}
        [HttpGet("my-results/{participantId}")]
        public async Task<IActionResult> GetMyResults(int participantId)
        {
            var results = await _context.Results
                .Include(r => r.Enrolment)
                .ThenInclude(e => e!.Category)
                .ThenInclude(c => c!.Event)
                .Where(r => r.Enrolment!.ParticipantID == participantId)
                .ToListAsync();

            return Ok(results);
        }
    }
}